package bioseguridadfinal;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;

public class Fecha {

    private int dia;

    private int mes;

    private int anio;

    public int getDia() {
        return dia;
    }

    public void setDia(int dia) {
        this.dia = dia;
    }

    public int getMes() {
        return mes;
    }

    public void setMes(int mes) {
        this.mes = mes;
    }

    public int getAnio() {
        return anio;
    }

    public void setAnio(int anio) {
        this.anio = anio;
    }

    

    public int calcularDiferenciaFechas() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        String fNacimiento = (dia+"/"+mes+"/"+anio);
        LocalDate fechaNacimiento = LocalDate.parse(fNacimiento,formatter);
        Period diferencia = Period.between(fechaNacimiento, LocalDate.now());
        return diferencia.getYears();
        
    }
}
