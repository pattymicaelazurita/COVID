package bioseguridadfinal;



import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

public class Persona {

    private String nombre;
    private String genero;
    private String cedula;
    private Fecha fechaNacimiento;
    private List<Encuesta> encuestas = new ArrayList<Encuesta>();
    
    public Persona(){
        
    }
    
    
    public Persona(String cedula, String nombre, String genero, Fecha fechaNacimiento,List<Encuesta> encuestas){
        setCedula(cedula);
        setNombre(nombre);
        setGenero(genero);
        setFechaNacimiento(fechaNacimiento);
        setEncuestas(encuestas);
    }


    public String getCedula() {
        return cedula;
    }

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

      
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public Fecha getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(Fecha fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public List<Encuesta> getEncuestas() {
        return encuestas;
    }

    public void setEncuestas(List<Encuesta> encuestas) {
        this.encuestas = encuestas;
    }
    

    public String mostrarRiesgo() {
        double riesgo=0;
        if(genero.equals("masculino")){
            if(fechaNacimiento.calcularDiferenciaFechas()<=29){
                riesgo=riesgo+0;
            }else if (fechaNacimiento.calcularDiferenciaFechas()<=39){
                riesgo=riesgo+0.4;   
            }else if (fechaNacimiento.calcularDiferenciaFechas()<=49){
                riesgo=riesgo+0.9;
            }else if (fechaNacimiento.calcularDiferenciaFechas()<=59){
                riesgo=riesgo+3.1;
            }else if (fechaNacimiento.calcularDiferenciaFechas()<=69){
                riesgo=riesgo+10;
            }else if (fechaNacimiento.calcularDiferenciaFechas()<=79){
                riesgo=riesgo+32;
            }else if (fechaNacimiento.calcularDiferenciaFechas()<=89){
                riesgo=riesgo+41.4;
            }else{
                riesgo=riesgo+11.5;
            }
        }
        else{
            if(fechaNacimiento.calcularDiferenciaFechas()<=29){
                riesgo=riesgo+0;
            }else if (fechaNacimiento.calcularDiferenciaFechas()<=39){
                riesgo=riesgo+0.4;   
            }else if (fechaNacimiento.calcularDiferenciaFechas()<=49){
                riesgo=riesgo+1.2;
            }else if (fechaNacimiento.calcularDiferenciaFechas()<=59){
                riesgo=riesgo+2.5;
            }else if (fechaNacimiento.calcularDiferenciaFechas()<=69){
                riesgo=riesgo+7.3;
            }else if (fechaNacimiento.calcularDiferenciaFechas()<=79){
                riesgo=riesgo+21.9;
            }else if (fechaNacimiento.calcularDiferenciaFechas()<=89){
                riesgo=riesgo+44;
            }else{
                riesgo=riesgo+22.2;
            }
        }
        
        
        return ("En caso de contraer Covid su riesgo de mortalidad es "+riesgo+"%");
    }

    public void anadirEncuesta(boolean salir, boolean contacto, boolean fiebre, boolean fatiga,boolean tos, 
                    boolean estornudos, boolean dolorMuscular, boolean congestion, 
                    boolean dolorGarganta, boolean diarrea, boolean dolorCabeza,
                    boolean dificultadRespirar, Fecha fechaEncuesta) {
        encuestas.add(new Encuesta(salir, contacto, fiebre, fatiga,tos,estornudos, dolorMuscular,congestion,dolorGarganta,diarrea, dolorCabeza,dificultadRespirar, fechaEncuesta));
    }

   
    public String mostrarInformacionEncuesta(Fecha fechaEncuesta) {
        boolean encontrar=false;
        String resultado="";
        String fi, fa,to, es, dm, co, dg, di, dc, dr, sa, con;
        for (Encuesta Encuesta : encuestas) {
            if (Encuesta.getFechaEncuesta()==(fechaEncuesta)) {
                encontrar = true;
                if ((Encuesta.getFiebre())==(true)){
                    fi="si";
                }else{
                    fi="no";
                }
                
                if ((Encuesta.getFatiga())==(true)){
                    fa="si";
                }else{
                    fa="no";
                }
                if ((Encuesta.getTos())==(true)){
                    to="si";
                }else{
                   to="no";
                }
                
                if ((Encuesta.getEstornudos())==(true)){
                    es="si";
                }else{
                    es="no";
                }
               
                if ((Encuesta.getDolorMuscular())==(true)){
                    dm="si";
                }else{
                    dm="no";
                }
                
                if ((Encuesta.getCongestion())==(true)){
                    co="si";
                }else{
                    co="no";
                }

                if ((Encuesta.getDolorGarganta())==(true)){
                    dg="si";
                }else{
                    dg="no";
                }
                
                if ((Encuesta.getDiarrea())==(true)){
                    di="si";
                }else{
                    di="no";
                }

                if ((Encuesta.getDolorCabeza())==(true)){
                    dc="si";
                }else{
                    dc="no";
                }
                
                if ((Encuesta.getDificultadRespirar())==(true)){
                    dr="si";
                }else{
                    dr="no";
                }

                if ((Encuesta.getSalir())==(true)){
                    sa="si";
                }else{
                    sa="no";
                }
                
                if ((Encuesta.getContacto())==(true)){
                    con="si";
                }else{
                    con="no";
                }
                
                resultado=("FechaEncuesta"+Encuesta.getFechaEncuesta().getDia()+Encuesta.getFechaEncuesta().getMes()+Encuesta.getFechaEncuesta().getAnio()+"\n*****Respuestas***"+"\nFiebre: "+fi+"\nFatiga: "+fa+"\nTos: "+to+"\nEstornudos: "+es+"\nDolor muscular: "+dm+"\nCongestion: " +con+"\nDolor de garganta: "+dg+"\nDiarrea: "+di+"\nDolor de cabeza: "+dc+"\nDificultadRespirar: "+dr+"\n¿se ha relacionado con personas que han llegado del extranjero?: "+sa+"\n¿se ha relacionado con personas que han llegado del extranjero?: "+co);
                break;
            }else{
                encontrar = false;

            }
        }
        if(encontrar==false){
            resultado = ("No se ha encontrado encuesta con la fecha ingresada");
        }
        return resultado;
    }

    public String verResultadoEncuesta(Fecha fechaEncuesta) {
        boolean encontrar=false;
        String resultado="";
        DecimalFormat df = new DecimalFormat("#.00");
        for (Encuesta Encuesta : encuestas) {
            if (Encuesta.getFechaEncuesta()==(fechaEncuesta)) {
                encontrar = true;
                resultado = ("Probabilidad Covid: %"+df.format(Encuesta.calcularProbabilidadCovid())+"\nProbabilidad Resfriado: %"+df.format(Encuesta.calcularProbabilidadResfriado())+"\nProbabilidad Gripe: %"+df.format(Encuesta.calcularProbabilidadGripe())+"\n\nProbabilidad más alta: %"+Encuesta.mostrarProbabilidadMasAlta());
                break;
            }else{
                encontrar = false;

            }
        }
        if(encontrar==false){
            resultado = ("No se ha encontrado encuesta con la fecha ingresada");
        }
        return resultado;
        
    }
    
    public String mostrarInformacion() {
        return ("Nombre: %"+nombre+"\nCédula: %"+cedula+"\nGénero: %"+genero+"\nFecha: %"+fechaNacimiento.getDia()+fechaNacimiento.getMes()+fechaNacimiento.getAnio());
    }
}
